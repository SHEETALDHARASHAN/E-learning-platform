package com.example.demo.f250;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.*;

@Controller
public class control {

    @GetMapping("/start")
    public String start() {
        return "login&signup";
    }
    @PostMapping("/signup")
    public String signup(@RequestParam("user-signup") String username,
                         @RequestParam("pass-signup") String password,
                         @RequestParam("email") String email) {
        System.out.println("Inside signup method");

        String url = "jdbc:mysql://localhost:3306/sheetal";
        String sqlun = "root";
        String sqlpass = "root";

        try (Connection connection = DriverManager.getConnection(url, sqlun, sqlpass)) {
            System.out.println("Database connection established");

            String sql = "INSERT INTO user (username, password, email) VALUES (?, ?, ?)";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, username);
                ps.setString(2, password);
                ps.setString(3, email);
                int rowsAffected = ps.executeUpdate();
                System.out.println(rowsAffected + " row(s) inserted");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database connection or query errors
            return "Error occurred during signup: " + e.getMessage();
        }

        return "login&signup";
    }
}
